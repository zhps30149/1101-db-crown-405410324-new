--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "1101_db_24";
--
-- Name: 1101_db_24; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "1101_db_24" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Chinese (Traditional)_Taiwan.950';


ALTER DATABASE "1101_db_24" OWNER TO postgres;

\connect "1101_db_24"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: category_24; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category_24 (
    id integer NOT NULL,
    name character varying,
    size character varying,
    remote_url character varying,
    local_url character varying,
    link_url character varying
);


ALTER TABLE public.category_24 OWNER TO postgres;

--
-- Name: shop_24; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shop_24 (
    id integer NOT NULL,
    name character varying(45),
    cat_id integer,
    price real,
    remote_url character varying(255),
    local_url character varying(255)
);


ALTER TABLE public.shop_24 OWNER TO postgres;

--
-- Data for Name: category_24; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category_24 (id, name, size, remote_url, local_url, link_url) FROM stdin;
\.
COPY public.category_24 (id, name, size, remote_url, local_url, link_url) FROM '$$PATH$$/2989.dat';

--
-- Data for Name: shop_24; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shop_24 (id, name, cat_id, price, remote_url, local_url) FROM stdin;
\.
COPY public.shop_24 (id, name, cat_id, price, remote_url, local_url) FROM '$$PATH$$/2990.dat';

--
-- Name: category_24 category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_24
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: shop_24 shop_24_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_24
    ADD CONSTRAINT shop_24_pkey PRIMARY KEY (id);


--
-- Name: shop_24 cat_24; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shop_24
    ADD CONSTRAINT cat_24 FOREIGN KEY (cat_id) REFERENCES public.category_24(id) ON UPDATE CASCADE ON DELETE SET NULL NOT VALID;


--
-- PostgreSQL database dump complete
--

